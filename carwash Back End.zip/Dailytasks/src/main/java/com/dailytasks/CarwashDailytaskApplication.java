package com.dailytasks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarwashDailytaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarwashDailytaskApplication.class, args);
	}

}
