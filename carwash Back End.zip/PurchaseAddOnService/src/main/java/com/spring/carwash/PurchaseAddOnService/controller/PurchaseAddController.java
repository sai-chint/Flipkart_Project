package com.spring.carwash.PurchaseAddOnService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.carwash.PurchaseAddOnService.model.PurchaseAddPojo;
import com.spring.carwash.PurchaseAddOnService.repository.PurchaseAddRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class PurchaseAddController {

	@Autowired
	private PurchaseAddRepository purchaseAddRepository;
	
	@PostMapping("/washservice")
	public void washService(@RequestBody PurchaseAddPojo pap) {
		System.err.println(pap); 
		purchaseAddRepository.save(pap);
	}
	
	 @GetMapping("/user/additionalpurchase")
		public List<PurchaseAddPojo> getAdditionalPurchase() {
			return purchaseAddRepository.findAll();
		}
}
