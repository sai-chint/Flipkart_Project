 package com.mebership.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="membership")
public class Membership {
	
	@Id
	private String id;
	String membershipName;
	String email;
	String freewash;
	String polishing;
	public Membership() {
		super();
		
	}
	public Membership(String id, String membershipName, String email, String freewash, String polishing) {
		super();
		this.id = id;
		this.membershipName = membershipName;
		this.email = email;
		this.freewash = freewash;
		this.polishing = polishing;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMembershipName() {
		return membershipName;
	}
	public void setMembershipName(String membershipName) {
		this.membershipName = membershipName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFreewash() {
		return freewash;
	}
	public void setFreewash(String freewash) {
		this.freewash = freewash;
	}
	public String getPolishing() {
		return polishing;
	}
	public void setPolishing(String polishing) {
		this.polishing = polishing;
	}
	@Override
	public String toString() {
		return "Membership [id=" + id + ", membershipName=" + membershipName + ", email=" + email + ", freewash="
				+ freewash + ", polishing=" + polishing + "]";
	}
	
}
