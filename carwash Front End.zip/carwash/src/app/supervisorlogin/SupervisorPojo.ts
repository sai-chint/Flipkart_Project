export class SupervisorPojo {
    name:string
    email:string
password:string
   
}
