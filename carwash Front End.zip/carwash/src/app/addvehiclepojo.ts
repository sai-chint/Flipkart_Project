export class AddvehiclePojo {
    vehiclenumber:string
brand:string
vehicleModel:string
   email:string
}
