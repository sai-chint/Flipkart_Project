export class RegisterPojo {
     email:string
 password:string
 repeatpassword:string
    
}
