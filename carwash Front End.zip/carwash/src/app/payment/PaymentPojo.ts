export class PaymentPojo {
   nameoncard:string
   creditcardnumber:string
   expmonth:string
   expyear:string
   cvv:string
   email:string
}
 