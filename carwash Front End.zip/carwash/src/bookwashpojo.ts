export class BookwashPojo {
    location:string
    date:string
    email:string 
}